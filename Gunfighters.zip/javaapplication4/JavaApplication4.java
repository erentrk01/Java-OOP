/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;

import java.util.Scanner;

/**
 *
 * @author Eren Tarak
 */
public class JavaApplication4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner input=new Scanner(System.in);
  
        player1 p1=new player1("Eren","machine gun",100);
      
        
//        p1.Gun1_damage();
//        p1.Gun1_damage();
//        p1.Gun2_damage();

       player2 strongP=new player2("Hitman","laser gun",100,true);
     System.out.println("How many gun load you want:");
     int gun_load=input.nextInt();
     System.out.println("Enter player choice(1 or 2):");
       int p_choice=input.nextInt();
        while(p_choice!=1&&p_choice!=2)
             {System.out.println("Invalid choice,try again!");
                   System.out.println("Enter player choice(1 or 2):");
        p_choice=input.nextInt();
               
               }
     for(int i=0;i<gun_load;i++)
         
     {
         
         
       // validation of player choice
            
               int g_choice;
               if(p_choice==1)
               {     
                   // validation of gun choice
                   System.out.println("Select a gun to kill your enemy(laser or machine) choice(1 or 2):");
                    g_choice=input.nextInt();
                     while(g_choice!=1&&g_choice!=2)
                     {System.out.println("Invalid gun choice!");
                     System.out.println("Select a gun to kill your enemy(laser or machine) choice(1 or 2):");
                    g_choice=input.nextInt();
                     }
                     
                     //shot
                     if(g_choice==1)
                     {
                         strongP.Gun1_damage();
                     }
                     
                     else{
                     strongP.Gun2_damage();
                     }
               }
               // player choice 2
               else{  
                     // validation of gun choice
                   System.out.println("Select a gun to kill your enemy(laser or machine) choice(1 or 2):");
                    g_choice=input.nextInt();
                     while(g_choice!=1&&g_choice!=2)
                     {System.out.println("Invalid gun choice!");
                     System.out.println("Select a gun to kill your enemy(laser or machine) choice(1 or 2):");
                    g_choice=input.nextInt();
                     }
                     
                     //shot
                     if(g_choice==1)
                     {
                         p1.Gun1_damage();
                     }
                     
                     else{
                     p1.Gun2_damage();
                     }
               
                      if(i==1)
                      p1.care();
               
               }
               
               
               
               
               
               
               
               
               
     }
     
        System.out.println("End of the game");
        
    }
}
