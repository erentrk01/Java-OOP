/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class player1 {
    private String name;
    private String weapon;
    private int health;
    
    public player1(String name,String weapon,int health){
    this.name=name;
    this.weapon=weapon;
    if (health<0 || health>100)
        this.health=100;
    else
    this.health=health;
    
}
    
    public void Gun1_damage(){
    this.health -=30;
    if(this.health<0)
        this.health=0;
        System.out.println("Got hit by Gun_1. Health is reduced by 30. " + "New health is " + this.health);
    if(this.health==0)
            System.out.println( getName() +  " is dead");
        
    }
    
    
    public void Gun2_damage(){
    this.health -=50;
    if(this.health<0)
        this.health=0;
        System.out.println("Got hit by Gun_2. Health is reduced by 50. " + "New health is " + this.health);
    if(this.health==0)
            System.out.println("Player is dead");
        
    }
    
    public void care(){
        
        if(this.health<=25)
        {System.out.println("Critical Health Alert! Get a health packet!");
          
          
            if(this.health<=0)
           {System.out.println("Player is dead, care packet cant be add");
           
           }
         else{
             this.health=100;
             System.out.println("Health care is activated, health:" + this.health );
          
         }
           
        }
        
        
        
    }
    

    public String getName() {
        return name;
    }

    public int getHealth() {
        return health;
    }

    public String getWeapon() {
        return weapon;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setWeapon(String weapon) {
        this.weapon = weapon;
    }

    public void setHealth(int health) {
        this.health = health;
    }
    
     
    
    
}
