/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class player2 extends player1 {
    private int health;
    public boolean shield;
    
    public player2(String name,String weapon,int health,boolean shield){
    super(name,weapon,health);
    this.health=health;
    this.shield=shield;
    
     
}
  
    @Override
   public void Gun1_damage(){
       if (shield)
       {this.health-=20;
       if(this.health<=0)
       {
           this.health=0;
       
           System.out.println("Shield is equiepped! Got hit by  gun1.Health is reduced by 20." +" New health is " + this.health);
       }
       }
       else
           this.health-=30;
       if(this.health<=0)
           this.health=0;
       
           System.out.println("Shield is equiepped! Got hit by  gun1.Health is reduced by 30." +" New health is " + this.health);
       
           
           if(this.health==0)
               System.out.println(getName() + "is died...");
       }
       
   
    @Override
   public void Gun2_damage()
   {
       if (shield)
       {this.health-=40;
       if(this.health<=0)
       {
           this.health=0;
       
           System.out.println("Shield is equiepped! Got hit by  gun1.Health is reduced by 40." + " New health is " + this.health);
       }
       }
       else
           this.health-=60;
       if(this.health<=0)
           this.health=0;
       
           System.out.println("Shield is equiepped! Got hit by  gun1.Health is reduced by 60." + " New health is " + this.health);
       
           
           if(this.health==0)
               System.out.println(getName() + "is died...");
       
       
       
   }
   
   //
   
  
   
   
   
   
   
   
   //
   }

   
   
   
   
   
   
   

   
   
   

